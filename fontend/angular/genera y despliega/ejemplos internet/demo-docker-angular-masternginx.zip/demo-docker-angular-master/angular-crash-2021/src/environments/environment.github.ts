export const environment = {
  production: true,
  apiUrl: 'https://my-json-server.typicode.com/tjmoon0104/demo-docker-angular/tasks'
};
